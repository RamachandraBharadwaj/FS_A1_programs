for i in range(1, 5):  
  print (i, " ", i * i)
print()

for i in range(0, 25, 5):  
  print (i, " ", i * i)

print()
print (list(range(0, -10, -1)))

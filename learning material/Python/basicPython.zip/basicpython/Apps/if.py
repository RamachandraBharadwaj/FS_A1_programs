x = int(input("Please enter an integer: "))
if x < 0:
  print('Less than zero')
elif x == 0:
  print('Zero')
else:
  print('greater than zero')

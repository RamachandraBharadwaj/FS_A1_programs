import PackageDemo.mod1

def g():
  x = 10
  print(x)
  print(PackageDemo.mod1.getX())


from PackageDemo import *

if __name__ == '__main__': 
  mod1.main()
# first script
x = "Genesis"
print (x)

""" 
multiline comments
Accepts data from console. Input returns a string. To convert it to int use int()
"""

str = input("Enter input: "); 
print(str, type(str))
print("Input is:", int(str))

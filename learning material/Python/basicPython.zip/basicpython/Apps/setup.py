from distutils.core import setup
setup(name='sub',  
  version='1.0', 
  author='Raj Tapadia',
  author_email='rtapadia@genesisinsoft.com',
  url='http://www.genesisinsoft.com/',
  packages=['sub'],
  package_dir={'sub': 'PackageDemo'},
  )
lst=[1,2,3]

print(lst, id(lst))

lst.append(5)
print(lst, id(lst))

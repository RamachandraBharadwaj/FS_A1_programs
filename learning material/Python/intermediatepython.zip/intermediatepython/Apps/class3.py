class Account:
  pass

customer = Account()
customer.name="ravi"
customer.number=100
customer.balance= 6000

print(customer.name)
print(customer.number)
print(customer.balance)

class Car(object):
  def factory(type):
    print("in factory")
    if type == "Racecar": 
      return Racecar()
    elif type == "Van": 
      return Van()
    raise AssertionError("Bad car creation: " + type)

  def drive(self):
    raise NotImplementedError(self, " subclass should implement it")
 
class Racecar(Car):
  def drive(self): print("Racecar driving")
 
class Van(Car):
  def drive(self): print("Van driving")
 
# Create object using factory.
try:
  types = ['Racecar', 'Van', 'Van', 'Racecar', 'Bus']
  Cars = [Car.factory(i) for i in types]
  print(Cars)
  for car in Cars:
    car.drive()
except AssertionError as ae:
  print(ae)
  
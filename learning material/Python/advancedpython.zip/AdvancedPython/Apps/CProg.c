/*
On Windows you have to specify __declspec(dllexport) in my function signatures
for Python to be able to see them. 

To compile and build the dll perform the 2 steps

1) cl -c CProg.c
2) cl /LD CProg.obj
*/

__declspec(dllexport) int cadd(x, y)
{
  return  x + y;
}
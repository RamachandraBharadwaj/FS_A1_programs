from threading import Thread
import threading

class Counter(object):
  def __init__(self):
    self.value = 0

  def increment(self):
    self.value += 1

c = Counter()

def run():
  for i in range(1000000):
    c.increment()

# Run two threads that increment the counter:
t1 = Thread(target=run)
t1.start()
t2 = Thread(target=run)
t2.start()

for i in threading.enumerate():
  print(i.name)

if(t1.name == 'Thread-1' and t1.is_alive()):
  print("thread t1 is running")

t1.join()
if(t1.name == 'Thread-1' and t1.is_alive()):
  print("thread t1 is running")
else:
  print("thread t1 has terminated")
t2.join()
print(c.value)








'''
We incremented 2,000,000 times, but that is not what we got. 
The problem is that self.value += 1 actually takes three distinct steps:

Getting the attribute,
incrementing it,
then setting the attribute.

If two threads call increment() on the same object around the same time, 
the following may happen:

Thread 1: Get self.value, which happens to be 17.
Thread 2: Get self.value, which happens to be 17.
Thread 1: Increment 17 to 18.
Thread 1: Set self.value to 18.
Thread 2: Increment 17 to 18.
Thread 1: Set self.value to 18.
An increment was lost due to a race condition.
'''
if __name__ == "__main__":
  # It creates a list of the square values in memory and then it iterates
  # over it and finally after returning sum it frees the memory 
  # Imagine the memory usage in case of a big list.

  print("Sum is", sum([x*x for x in range(1,10)]))

  # We can save memory usage by using a generator expression.

  # generator expression logic
  genSum = sum(x*x for x in range(1,10))
  print("gen sum is",genSum)

  # generator expression logic
  genExp = (i*i for i in range(10, 15))
  print(list(genExp))
from threading import Thread
import threading
import time 

class Counter(object):
  def __init__(self):
    self.value = 0

  def increment(self):
    self.value += 1
 
  def decrement(self):
    self.value -= 1

c = Counter()
c1 = Counter()

def runI(*lst):
  print("runI ", lst)
  for i in range(1000000):
    c.increment()
 
  time.sleep(2)
  print("runI: ",c.value)

def runD(*lst):
  print("runD ", lst)
  for i in range(1000000):
    c1.decrement()

  time.sleep(2)
  print("runD: ",c1.value)


t1 = Thread(target=runI, name="t1", args = (1,2,3,4,5), daemon=True)
t1.start()
t2 = Thread(target=runD, name="t2", args = (6,7), daemon=False)
t2.start()

print(t1.isDaemon(), t2.isDaemon())

for i in threading.enumerate():
  print(i.name)

if(t1.name == 't1' and t1.isAlive()):
  print("thread t1 is running")

for i in threading.enumerate():
  print(i.name)

print(c.value)
print(c1.value)
print(t1.isAlive())
print(t2.isAlive())


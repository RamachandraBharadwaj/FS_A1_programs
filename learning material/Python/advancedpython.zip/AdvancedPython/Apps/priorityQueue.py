import threading ,queue

class Accno:
  def __init__(self,number,bal):
    self.number = number
    self.balance = bal

  def __lt__(self,other):
    if self.balance < other.balance:
      return True
    return False
 
  def __str__(self):
    return ("number: "+str(self.number)+", "+"Balance: "+str(self.balance))

def run(oQ,*acc):
  for i in acc:
    oQ.put(i)

outQueue = queue.PriorityQueue()
acc1=Accno('1',100)
acc2=Accno('2',20)
acc3=Accno('3',250)
acc4=Accno('4',1000)
acc5=Accno('5',10)

t1=threading.Thread(target=run,name="t1",args=(outQueue,acc1,acc2,acc3,acc4,acc5))
t1.start()
t1.join()

for i in range(outQueue.qsize()):
  print(outQueue.get())
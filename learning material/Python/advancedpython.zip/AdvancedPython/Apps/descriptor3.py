class Person(object):
  def __init__(self):
    self._name = ''

  @property
  # the name property. The decorator creates a read-only property
  def name(self):
    print("Getting: ", self._name)
    return self._name

  @name.setter
  # the name property setter makes the property writeable
  def name(self, value):
    print("Setting: ", value)
    self._name = value

  @name.deleter
  # the name property setter makes the property deletable
  def name(self):
    print("Deleting: ", self._name)
    del(self._name)

obj = Person()
obj.name = "raj";
print(obj.name)
del(obj.name)
print(obj.name)

def getText(name):
  return "{0}".format(name)

def p_decorate(func):
  def func_wrapper(name):
    return "<p>{0}</p>".format(func(name))
  return func_wrapper

def b_decorate(func):
  def func_wrapper(name):
    return "<B>{0}</B>".format(func(name))
  return func_wrapper

func1 = p_decorate(getText)
print(func1("Genesis"))

# Remove few or all and test
@p_decorate
@b_decorate
def getText2(name):
   return "{0}".format(name)

print(getText2("Hyderabad"))

# without decorator syntax
func2 = p_decorate(b_decorate(getText))
print(func2("Hyderabad"))

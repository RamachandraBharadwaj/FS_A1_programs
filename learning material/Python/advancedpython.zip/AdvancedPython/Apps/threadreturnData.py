import threading, queue

def getSquares(num, oQ):
  lst = []
  for i in range(num):
    lst.append(i * i)
  oQ.put(lst)
  oQ.put(sum(lst))
  
outQueue = queue.Queue()
num = 5

t1 = threading.Thread(target=getSquares, name="t1", args = (num, outQueue), daemon=False)
t1.start()
t1.join()

for x in range(outQueue.qsize()):
  print(outQueue.get())


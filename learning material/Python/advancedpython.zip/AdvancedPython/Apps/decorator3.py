def trace(func):
  def wrapper(*args, **kwargs):
    result = func(*args, **kwargs)
    print('%s(%r, %r) -> %r' %(func.__name__, args, kwargs, result))
    return result
  return wrapper

@trace
def fibonacci(n):
  result = []
  a, b = 0, 1
  while b < n:
    result.append(b) 
    a, b = b, a + b
  return result

print(fibonacci(3))


@trace
def add(*args, **kwargs):
  '''Return the sum of arguments'''
  return sum(args)

d = {}
d['1'] = 'Ravi'
d['2'] = 'Ajay'

print(add(1,2,3,4,5, **d))

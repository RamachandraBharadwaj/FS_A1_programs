import time 
import math 

# decorator to calculate duration taken by any function. 
def calculate_time(func): 	
	# added arguments inside the inner1, if function takes any arguments, 
	# can be added like this. 
	def inner1(*args, **kwargs): 
		# storing time before function execution 
		begin = time.time() 
		
		func(*args, **kwargs) 

		# storing time after function execution 
		end = time.time() 
		print("Total time taken: ", func.__name__, end - begin) 
	return inner1 

@calculate_time
def factorial(num): 
	# sleep 1 second-to see the actual difference 
	time.sleep(1) 
	print(math.factorial(num)) 

factorial(5) 
func = calculate_time(factorial)
func(6)

class Facade:
  """
  Know which subsystem classes are responsible for a request.
  Delegate client requests to appropriate subsystem objects.
  """
  def __init__(self):
    self._subsystem_1 = Subsystem1()
    self._subsystem_2 = Subsystem2()

  def operation1(self):
    self._subsystem_1.sort()
    self._subsystem_1.search()
 
  def operation2(self):
    self._subsystem_2.generateReport()
    self._subsystem_2.getData()

class Subsystem1:
  """
  Implement subsystem functionality.
  Handle work assigned by the Facade object.
  Has no knowledge of the facade.
  """

  def sort(self):
    print("Subsystem1 sort invoked")

  def search(self):
    print("Subsystem1 search invoked")

class Subsystem2:
  """
  Implement subsystem functionality.
  Handle work assigned by the Facade object.
  Has no knowledge of the facade.
  """

  def generateReport(self):
    print("Subsystem2 generateReport invoked")

  def getData(self):
    print("Subsystem2 addData invoked")

if __name__ == "__main__":
  facade = Facade()
  facade.operation1()
  facade.operation2()

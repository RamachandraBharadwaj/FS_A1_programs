#include <iostream>
using namespace std;

class operation {
  public:
    int add(int num1, int num2){
        return num1 + num2;
    }
    int mult(int num1, int num2){
        return num1 * num2;
    }
};

/*
Since ctypes can only talk to C functions, we need to provide those 
them as extern "C" and export them for Python to see
*/

extern "C" {
  __declspec(dllexport) operation* operation_new(){ 
      return new operation(); 
    }

  __declspec(dllexport) int operation_add(operation* obj, int n1, int n2) { 
      return obj->add(n1, n2); 
    }

  __declspec(dllexport) int operation_mult(operation* obj, int n1, int n2) { 
      return obj->mult(n1, n2); 
    }
}

/*
cl -c CppProg.cpp
cl /LD CppProg.obj
*/

import py_compile
py_compile.compile('decorator1.py')
class proxyImpl:
  def f1(self):
    print("Actual call to f1() method")

class Proxy:
  def __init__(self):
    print("in Init of Proxy")
    self.__implementation = proxyImpl()

  # Pass method calls to the actual implementation:
  def f1(self): 
    print("in f1 of Proxy")
    self.__implementation.f1()

class Proxy2:
  def __init__(self):
    print("in Init of Proxy2")
    self.__implementation = proxyImpl()

  def __getattr__(self, name):
    print("in __getattr__", name)
    return getattr(self.__implementation, name)

p1 = Proxy()
p1.f1() 

p2 = Proxy2()
p2.f1()

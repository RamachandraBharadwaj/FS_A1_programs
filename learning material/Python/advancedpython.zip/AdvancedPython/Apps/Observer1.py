class Publisher:
  def __init__(self):
    pass
  def register(self):
    pass
  def unregister(self):
    pass
  def notifyAll(self):
    pass

class TechForum(Publisher):
  def __init__(self):
    self._listOfUsers = []
    self.postname = None

  def register(self, userObj):
    if userObj not in self._listOfUsers:
      self._listOfUsers.append(userObj)

  def unregister(self, userObj):
    self._listOfUsers.remove(userObj)

  def notifyAll(self):
    for objects in self._listOfUsers:
      objects.notify(self.postname)

  def writeNewPost(self, postname):
    self.postname = postname
    # Submits the post published and notification is sent to all
    self.notifyAll()

class Subscriber:
  def __init__(self):
    pass

  def notify(self):
    pass

class User1(Subscriber):
  def notify(self,postname):
    print('User1 notified of a new post: %s' % postname)

class User2(Subscriber):
  def notify(self, postname):
    print('User2 notified of a new post: %s' % postname)

class websites(Subscriber):
  def __init__(self):
    self._websites = ["genesisinsoft.com","qualcomm.com"]

  def notify(self, postname):
    for site in self._websites:
      # Send updates
      print("Sent nofication to %s of: %s " % (site, postname))

if __name__ == "__main__":
  techForum = TechForum()
  user1 = User1()
  user2 = User2()
  wsites = websites()
  techForum.register(user1)
  techForum.register(wsites)
  techForum.writeNewPost("Observer Pattern in Python")
  techForum.register(user2)
  techForum.unregister(wsites)
  techForum.writeNewPost("Advanced Python training announced")
with open("cm1.txt", "w") as file1:
  file1.write("with context manager")

print(file1.closed)

# Following line gives an error as file1 is closed
file1.write("next line")

file1 = open("cm1.txt", "w")
try:
  file1.write("without context manager")
finally:
  file1.close()

print(file1.closed)

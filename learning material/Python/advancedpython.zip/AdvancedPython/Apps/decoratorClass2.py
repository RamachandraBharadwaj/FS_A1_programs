from time import time, sleep 

class Timer: 
  def __init__(self, func): 
    self.function = func 

  def __call__(self, *args, **kwargs): 
    start_time = time() 
    print(*args, self.function)
    result = self.function(*args, **kwargs) 
    end_time = time() 
    print("Execution took {} seconds".format(end_time-start_time)) 
    return result 

@Timer
def square(n): 
  sleep(1) 
  return n * n 
  
print("Square of number is:", square(5)) 
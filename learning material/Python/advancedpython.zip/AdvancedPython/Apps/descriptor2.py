class Account(object):
  def __init__(self):
    self._acctNo = None

  def get_acctNo(self):
    print("in get")
    return self._acctNo

  def set_acctNo(self, value):
    print("in set")
    self._acctNo = value

  def del_acctNo(self):
    print("in del")
    del self._acctNo

  acctNo = property(get_acctNo, set_acctNo, del_acctNo, "Account number property.")

acct = Account()
print(acct.acctNo)    # Invokes the getter
acct.acctNo = 100     # Invokes the setter
print(acct.acctNo)
del(acct.acctNo)

# You will get an error if this is uncommented as acctNo attribute is deleted
#print(acct.acctNo)

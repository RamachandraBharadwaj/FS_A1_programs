class Log:
  def __init__(self,filename):
    self.filename=filename
    self.fp = None    

  def logging(self,text):
    self.fp.write(text + '\n')

  def __enter__(self):
    print("__enter__")
    self.fp = open(self.filename,"w")
    return self    

  def __exit__(self, exception_type, exception_value, traceback):  
    print("__exit__")
    print(exception_type)
    print(exception_value)
    print(traceback)
    self.fp.close()

with Log("sample.txt") as logfile:
  print("Main")
  logfile.logging("line 1")
  logfile.logging("line 2")
  # raise an exception as hello.txt file is not found
  file1= open("hello.txt", "r")

from ctypes import cdll

class CppTest(object):
  def __init__(self):
    self.obj = lib.operation_new()

  def add(self, n1, n2):
    return lib.operation_add(self.obj, n1, n2)

  def mult(self, n1, n2):
    return lib.operation_mult(self.obj, n1, n2)

try:
  lib = cdll.LoadLibrary("E:\Tapadia\Python-All\Advanced Python\Apps\CppProg.dll")
  obj = CppTest()
  print("Add result: ", obj.add( 4,10))
  print("Mult result: ", obj.mult(2,3))
except Exception as e:
  print("Exception ", e)

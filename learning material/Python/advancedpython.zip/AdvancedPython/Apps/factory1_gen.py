class Car(object):
  def factory(type):
    print("in factory")
    if type == "Racecar":
      yield Racecar()
    elif type == "Van":
      yield Van()

    raise AssertionError("Bad car creation: " + type)

  def drive(self):
    raise NotImplementedError(self, " Subclasses should implement it.")
 
class Racecar(Car):
  def drive(self): print("Racecar driving")
 
class Van(Car):
  def drive(self): print("Van driving")
 
# Create object using factory.
try:
  count = 1
  types = ['Racecar', 'Van', 'Van', 'Racecar', 'Bus']
  Cars = (Car.factory(i) for i in types)
  print(Cars)
  for car in Cars:
    print(count)
    next(car).drive()
    count += 1
except AssertionError as ae:
  print(ae)
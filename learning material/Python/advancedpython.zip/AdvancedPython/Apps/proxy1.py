class IMath:
  """Interface for proxy and real subject."""
  def add(self, x, y):
    raise NotImplementedError()

  def div(self, x, y):
    raise NotImplementedError()

class Math(IMath):
  """Real subject."""
  def add(self, x, y):
    return x + y

  def div(self, x, y):
    return x / y

class Proxy(IMath):
  """Proxy."""
  def __init__(self):
    self.math = Math()

  def add(self, x, y):
    return self.math.add(x, y)

  def div(self, x, y):
    if y == 0:
      return float('inf') 
    return self.math.div(x, y)

p = Proxy()
x = 10
y = 5
print(p.add(x, y))
print(p.div(x, y))

'''
A lambda expressions (or lambda forms) are utilized to construct anonymous functions. 
We use the lambda keyword (just as you use def to define normal functions).

Every anonymous function you define in Python will have 3 essential parts:

The lambda keyword.
The parameters (or bound variables), and
The function body.

A lambda function can have any number of parameters, but the function body can only contain one expression.

Moreover, a lambda is written in a single line of code and can also be invoked immediately.

One of the most common use cases for lambdas is in pythons functional programming.

It allows you to provide a function as a parameter to another function (for example, in map,
filter, etc.). In such cases, using lambdas offer an elegant way to create a one-time 
function and pass it as the parameter.
'''

add = lambda n1, n2 : n1 + n2
print(add(1, 2))

(lambda x: print(x + x))(2) 

# What a lambda returns
data = 'qualcomm'
print(lambda data : print(data))

#What a lambda returns #2
data = 'genesis'

x = (lambda data : print(data))
x(data)

(lambda data : print(data))(data)

x = lambda a : a + 10
print(x(5))

x = lambda a, b, c : a + b + c
print(x(1, 5, 3))

def func1(n):
  return lambda a : a * n

lfunc = func1(2)

print(lfunc(7))

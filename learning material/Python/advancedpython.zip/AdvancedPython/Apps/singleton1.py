# Singleton instance. __dict__ : Dictionary containing the class's namespace

class Singleton(object):
  def __new__(cls):
    print("cls", cls, cls.__dict__)
    if not '_the_instance' in cls.__dict__:
      print("if")
      cls._the_instance = object.__new__(cls)
    return cls._the_instance
 
if __name__ == '__main__':
  obj1 = Singleton()
  obj1.data = 12

  obj2 = Singleton()
  obj2.name = "Genesis"

  obj3 = Singleton()

  print(obj3.name)
  print(obj3.data)
  print(id(obj1), id(obj2), id(obj3)) 

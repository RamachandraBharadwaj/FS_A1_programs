class IData:
  def getData(self):
    raise NotImplementedError(self, " getData() Subclasses should implement it.")
 
  def updateData(self):
    raise NotImplementedError(self, " updateData() Subclasses should implement it.")

  def deleteData(self):
    raise NotImplementedError(self, "  deleteData() Subclasses should implement it.")

  def insertData(self):
    raise NotImplementedError(self, " insertData() Subclasses should implement it.")

class file(IData):
  pass

class db(IData):
  pass

class socket(IData):
  pass

obj = socket()
obj.getData()
obj.updateData()
obj.deleteData()
obj.insertData()
# Assign functions to variables

def f1(name):
  return "Hello "+name

func = f1
print(func("Gen1"))

# Define functions inside other functions

def f2(name):
  def get_message():
    return "Hello "

  result = get_message()+name
  return result

print(f2("Gen2"))

# Functions can be passed as parameters to other functions

def f2(name):
 return "Hello " + name 

def call_func(func):
  other_name = "Gen3"
  return func(other_name)  

print(call_func(f2))

# Functions can return other functions (functions generating other functions).
# Closures are functions that are returned by another function. 

def outer():
  def inner():
    # inner is a closure
    return "Hello Gen4"

  return inner

innerF = outer()
print(innerF())

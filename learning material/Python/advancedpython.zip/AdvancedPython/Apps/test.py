'''
write a program to read the array of elements and r value to rotate the array elements by r times

for example:
input =1 2 3 4 5 6 7
2
output =3 4 5 6 7 1 2

input =7 6 5 4 3
3
output =4 3 7 6 5


input =-1 -3 4 5 2 -6
5
output =-6 -1 -3 4 5 2
'''
def rotatearr(arr,r):
  lst = arr[r:]
  for x in arr[:r]:
    lst.append(x)
  return lst

arr=list(input().split())
r=int(input())
res=rotatearr(arr,r)
for i in range(len(res)):
	print(res[i], end=" ")

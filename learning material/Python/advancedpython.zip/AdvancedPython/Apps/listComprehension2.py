Celsius = [40, 45, 33, 39]
Fahrenheit = [((float(9)/5)*x + 32) for x in Celsius]
print (Fahrenheit)

# Cross product of sets
marks = [90, 80, 85]
subjects = ["java", "Oracle", "C"]
sub_marks = [(x,y) for x in marks for y in subjects]
print(sub_marks)

lst = []

# Without list comprehension
for x in [20, 40, 60]:
    for y in [2, 4, 6]:
        lst.append(x * y)

print(lst)

# With list comprehension
my_list = [x * y for x in [20, 40, 60] for y in [2, 4, 6]]
print(my_list)

# without list comprehesion
sentence = "Genesis Insoft Limited a name you can trust"
words = sentence.split()
newWords = []
newWords_length = []
for word in words:
  if word != "name":
    newWords.append(word)
    newWords_length.append(len(word))

print(newWords)
print(newWords_length)

# with list comprehension
sentence = "Genesis Insoft Limited a name you can trust"
words = sentence.split()
newWords = []

newWords = [[word,len(word)] for word in words if word != "name"]
print(newWords)
print(newWords[0])
print(newWords[1][0])
print(newWords[2][1])

lst = [x for x in range(50) if x % 3 == 0 if x % 5 == 0]
print(lst)

lst = [x if x % 3 == 0 else x + 5 for x in range(10) ]
print(lst)

lst = [x if x%5==0 else (x+5 if x%2==0 else x) for x in range(10)]
print(lst)
class test(object):
  class_var = 1
  def __init__(self, i_var):
    self.i_var = i_var

obj1 = test(2)
obj2 = test(3)

print(test.__dict__)
print(obj1.__dict__)
print(obj2.__dict__)
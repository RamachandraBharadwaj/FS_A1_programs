# To test the c code built using CProg.c (CProg.dll)

from ctypes import cdll

try:
  lib = cdll.LoadLibrary("E:\Tapadia\Python-All\Advanced Python\Apps\CProg.dll")
  print(lib.cadd(1, 2))
except Exception as e:
  print("Exception ", e)

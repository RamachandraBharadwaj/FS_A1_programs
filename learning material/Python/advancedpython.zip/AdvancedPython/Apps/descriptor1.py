class checkType(object):
  def __init__(self, name, type, default=None):
    self.name = "_" + name
    self.type = type
    if default is None:
      self.default = type()
    else:
      self.default = default

  def __get__(self, instance, cls):
    return getattr(instance, self.name, self.default)

  def __set__(self,instance,value):
    if not isinstance(value,self.type):
      raise TypeError("Must be a %s" %self.type) 
    setattr(instance,self.name,value)

  def __delete__(self,instance):
    raise AttributeError("Can't delete attribute")

class demo(object):
  name = checkType("name",str) 
  num = checkType("num",int,42)

obj = demo()
obj.name = "Genesis"
print(obj.name)
print(obj.num)

del obj.name

obj.name = [1,2]
obj.num = "gen"

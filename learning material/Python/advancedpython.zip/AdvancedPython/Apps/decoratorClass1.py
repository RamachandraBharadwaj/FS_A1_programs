'''
The __call__ method enables us to write classes where the instances 
behave like functions. Both functions and the instances of such
classes are called callables.

any() function accepts iterable (list, tuple, dictionary etc.) as an argument 
and return true if any of the element in iterable is true, else it returns false.
If iterable is empty then any() method returns false.
'''

class ErrorCheck: 
  def __init__(self, function): 
    self.function = function 

  def __call__(self, *params): 
    lst = [isinstance(i, str) for i in params]
    print(lst)
    if any(lst): 
      raise TypeError("parameter is a string") 
    else: 
      return self.function(*params) 

@ErrorCheck
def add(*numbers): 
	return sum(numbers) 

f = add
print(f(1,2,3))

print(add(2,3,4))
print(add(5,'6'))

def square(start, stop):
  for i in range(start, stop):
    print("before yield ", i)
    yield i * i
    print("after yield ", i)
  print("End")

def cube(start, stop):
  for i in range(start, stop):
    print("i:", i)
    yield i * i * i

if __name__ == "__main__":
  genSq = square(5, 10)
  print(next(genSq))
  print("first")
  print(next(genSq))
  print("second")

  genCube = cube(2,6)
  print(list(genCube))
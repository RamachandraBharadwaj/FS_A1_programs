# Performing mathematical operations on the entire list
my_list = [2, 3, 5, 7, 11]
squared_list = [x**2 for x in my_list]    # list comprehension
print(squared_list, type(squared_list))

squared_dict = {x:x**2 for x in my_list}    # dict comprehension
print(squared_dict, type(squared_dict))

# Performing conditional filtering operations on the entire list
my_list = [2, 3, 5, 7, 11]

squared_list = [x**2 for x in my_list if x%2 != 0]    # list comprehension
print(squared_list, type(squared_list))

squared_dict = {x:x**2 for x in my_list if x%2 != 0}    # dict comprehension
print(squared_dict, type(squared_dict))

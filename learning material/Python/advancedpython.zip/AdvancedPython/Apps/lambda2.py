from functools import reduce

'''

lambdas in filter()
The filter function is used to select some particular elements from a sequence of
elements. The sequence can be any iterator like lists, sets, tuples, etc.

The elements which will be selected is based on some pre-defined constraint.
It takes 2 parameters:

A function that defines the filtering constraint
A sequence (any iterator like lists, tuples, etc.)

'''

lst = [5, 10, 2, 7, 5, 4, 3, 11, 1, 0]
result = filter(lambda x : x > 4, lst) 
print(list(result))


'''
lambdas in map()
The map function is used to apply a particular operation to every element in a
sequence. Like filter(), it also takes 2 parameters:

A function that defines the operation to perform on the elements

'''
lst = [5, 10, 2, 7, 8, 5, 4, 3, 11, 2, 1, 0]
result = map(lambda x : x*x, lst) 
print(list(result))

'''
lambdas in reduce
The reduce function, like map(), is used to apply an operation to every element
in a sequence. However, it differs from the map in its working. 
These are the steps followed by the reduce() function to compute an output:

Step 1) Perform the defined operation on the first 2 elements of the sequence.
Step 2) Save this result
Step 3) Perform the operation with the saved result and the next element in the
sequence.
Step 4) Repeat until no more elements are left.
'''

lst = [1,2,3,4,5]
product = reduce(lambda x, y : x * y, lst)
print(product)

'''
Lambdas vs. Regular functions

Lambdas are functions which do not have an identifier bound to them. 
In simpler words, they are anonymous functions. 

Lambda functions can only have one expression in their body.

Regular functions can have multiple expressions and statements in their body.

Lambdas do not have a name associated with them (anonymous functions).

Regular functions must have a name and signature.

Lambdas do not contain a return statement because the body is automatically returned.

Functions which need to return value should include a return statement.
'''

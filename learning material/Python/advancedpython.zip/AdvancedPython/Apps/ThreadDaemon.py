import threading
import time

def runa():
  print('Started thread:', threading.currentThread().name)
  time.sleep(2)
  print('Finished thread:', threading.currentThread().name)


def runb():
  print('Started thread:', threading.currentThread().name)
  print('Finished thread:', threading.currentThread().name)

a = threading.Thread(target=runa, name='Thread-a', daemon=True)
b = threading.Thread(target=runb, name='Thread-b')

a.start()
b.start()
class shape(object):
  def draw(self):             
    raise NotImplementedError("Subclass must implement abstract method: draw")

class circle(shape):
  def draw(self):             
    print("circle draw invoked")

class rectangle(shape):
  def draw(self):             
    print("rectangle draw invoked")

class Facade:
  def __init__(self):
    self._circle = circle()
    self._rectangle = rectangle()

  def drawCircle(self):
    self._circle.draw()

  def drawRectangle(self):
    self._rectangle.draw()

if __name__ == "__main__":
  facade = Facade()
  facade.drawCircle()
  facade.drawRectangle()

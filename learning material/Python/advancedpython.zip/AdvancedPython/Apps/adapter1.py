# Square-pin to round-pin adapter
# Consider two incompatible interfaces: round-pin powerSocket & square-pin laptop.
# The laptop expects a square-pin connection for it to work.
# The Adapter takes square-pin of laptop, and connects to round-pin powerSocket.
 
# Adaptee: Incompatible interface # 1
class powerSocket:
  pinType = "Round"
     
# The Adapter: acts as an interface between two incompatible interfaces
class Adapter:
  powerSocket = None
  pinType = "SquareToRound"
   
  def __init__(self, powerSocket):
    self.powerSocket = powerSocket
 
# Client: Incompatible interface # 2
class laptop:
  adapter = None
  pinType = "Square"

  def __init__(self, adapter):
    self.adapter = adapter

  def start(self):
    print(self.adapter.pinType)
    print(self.pinType, self.adapter.powerSocket.pinType)

    if self.adapter.pinType == \
      (self.pinType + "To" + self.adapter.powerSocket.pinType): 
      
      print("System start")
      print("Login window display")
    else:
      print("No power. Can't function.") 
 
# Create a powerSocket
roundPinpowerSocket  = powerSocket()
# Connect adapter and powerSocket
squareToRoundAdapter = Adapter(roundPinpowerSocket)
# Connect laptop and powerSocket via adapter.
laptopObj  = laptop(squareToRoundAdapter) 
laptopObj.start() 

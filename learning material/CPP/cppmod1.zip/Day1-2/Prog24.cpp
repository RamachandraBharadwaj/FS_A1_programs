int main()
{
	const int x = 57;
	const float y = 12.5;
  return 1;
}

float x2 (float value)
{
	return (2 * value);
}          

int main()
{
	int a = 10;
	float b = x2("1234");
  return 1;
}

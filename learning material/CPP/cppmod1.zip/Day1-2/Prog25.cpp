char *buffer, *name;
int main()
{
	const  char *p = buffer;
	p = name;
	*p = 'x';					// illegal
  return 1;
}

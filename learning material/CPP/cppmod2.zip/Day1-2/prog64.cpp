# include "prog64.h"

void main()
{
	combined_int_vector a(3, 11, 2, -1);
	a[7] = 4;
	cout << a << endl;
}
